alert("Hello World!");

var x = 2;
var y = 3;

var add =(x+y);

console.log(add);

var a = "Happy"
var b = "Friday"

var name =(a+b)

alert(name);

var bio = {firstName:"Ryan", lastName:"Courtney", city:"Philadelphia", 
state:"Pennsylvania", zip:"19125"};

console.log(bio);

var time = 9

if (time < 10) {
	alert("It's Early");
} else {
	alert("It's Late")}


var x = 100
while(x >= 0){
console.log(x--)
}









